﻿#include <cstdio>
#include <iostream>
#include "ExeSolution.h"
using namespace std;

int main()
{
	ExeSolution run;
	run.runProgram();
	
    return 0;
}