#include "ExeSolution.h"

int ExeSolution::runProgram()
{
	try
	{
		readData();
		if (!graph->IsConnectedVisit())
		{
			ProgramException e;
			e.isConnected = false;

			throw e;
		}
		else {
			int maxFlow = 0;
			auto maxFlowBfs = getMaxFlow(*graph, S, T, false);
			cout << "BFS Method:" << endl;
			cout << "Max flow = " << maxFlowBfs << endl;
			findMinCut(*graph, S, T);

			auto maxFlowDji = getMaxFlow(*djGraph, S, T, true);
			cout << "Greedy Method:" << endl;
			cout << "Max flow = " << maxFlowDji << endl;
			findMinCut(*djGraph, S, T);
			
			return 0;
		}
	}
	catch (ProgramException e)
	{
		if (!e.isConnected)
		{
			cout << e.what() << endl;
			cout << "The graph is not connected\n";
		}
		return 0;
	}
	catch (...)
	{
		cout << "Unknown error\n";
		return 0;
	}
}

ExeSolution::~ExeSolution()
{
	delete graph;
}

void ExeSolution::readData()
{
	int numOfVertices = 0, numOfArcs = 0, s = 0, t = 0;
	vector<graphArc> edgesArrInput; //TODO data meberm

	while (numOfVertices <= 0) {
		cout << "Enter the number of vertices in the graph\n";
		cin >> numOfVertices;//TODO EXCEPTION
	}

	while (numOfArcs <= 0) {
		cout << "Enter the number of arcs in the graph\n";
		cin >> numOfArcs;//TODO EXCEPTION
	}

	while (s <= 0) {
		cout << "Enter s\n";
		cin >> s;
	}

	while (t <= 0) {
		cout << "Enter t\n";
		cin >> t;
	}
	if (s == t)
	{
		ProgramException e;
		e.isConnected = false;
		throw e;
	}
	else
	{
		S = s - 1;
		T = t - 1;

		for (int i = 0; i < numOfArcs; i++)
		{
			int v1 = 0, v2 = 0, capacity = 0;
			cout << "Enter v1, v2, capacity\n";
			cin >> v1 >> v2 >> capacity;
			//TODO EXCEPTION- >0
			edgesArrInput.push_back(graphArc(v1 - 1, v2 - 1, capacity));
		}

		createGraphFromInput(numOfVertices, numOfArcs, edgesArrInput);
	}

}

void ExeSolution::createGraphFromInput(const int& vertixAmount, const int& arcsAmount, const vector<graphArc>& edgesArrInput)
{
	graph = new Graph(vertixAmount);
	djGraph = new Graph(vertixAmount);

	graph->vertixAmount = vertixAmount;

	for (int i = 0; i < arcsAmount; i++)
	{
		graphArc arc = edgesArrInput[i];
		graph->AddArc(edgesArrInput[i].startVertex, edgesArrInput[i].endVertex, edgesArrInput[i].capacity, true);
		djGraph->AddArc(edgesArrInput[i].startVertex, edgesArrInput[i].endVertex, edgesArrInput[i].capacity, true);
		graph->AddArc(edgesArrInput[i].endVertex, edgesArrInput[i].startVertex, 0, false);
		djGraph->AddArc(edgesArrInput[i].endVertex, edgesArrInput[i].startVertex, 0, false);
	}

}

int ExeSolution::getMaxFlow(Graph& graph, int source, int sink, bool isItGreedyMethod)
{
	int maxFlow = 0;
	vector<int> parent(graph.vertixAmount);
	int pathFlow = INT_MAX;

	while (true) {
		if (isItGreedyMethod) {
			if (!Djikstra(graph, source, sink, parent))
				break;
		}
		else {
			if (!BFS(source, sink, parent))
				break;
		}


		for (int v = sink; v != source; v = parent[v])
		{
			pathFlow = min(pathFlow, graph.GetAdjList(parent[v]).head->capacity);
		}
		for (int v = sink; v != source; v = parent[v])
		{
			int u = parent[v];
			graph.IncreaseArcFlow(u, v, pathFlow, false);//u->v,  false=forward
			graph.IncreaseArcFlow(v, u, -pathFlow, true);//v->u,  true=opposite edge

			maxFlow += pathFlow;

		}
		return maxFlow;

	}
}
void ExeSolution::findMinCut(Graph& graph, int source, int sink)
{
	vector<int> parent(graph.vertixAmount);
	vector<int> minCut_S, minCut_T;
	
	for (int i = 0; i < graph.vertixAmount; i++) {
		parent[i] = -1;
	}
	
	BFS(source, sink, parent);
	minCut_S.push_back(source + 1);
	for (int i = 1; i < graph.vertixAmount; i++)
	{
		if (parent[i] != -1)
		{
			minCut_S.push_back(i + 1);
		}
		else
		{
			minCut_T.push_back(i + 1);
		}
	}
	
	cout << "Min cut: S = { ";
	for (auto i : minCut_S)
	{
		if (i == minCut_S.back())
		{
			cout << i;
		}
		else
		{
			cout << i << ", ";
		}
	}
	cout << " }";
	cout << " T = { ";
	for (auto i : minCut_T)
	{
		if (i == minCut_T.back())
		{
			cout << i;
		}
		else
		{
			cout << i << ", ";
		}
	}
	cout << " }";
	cout << endl;
}


bool ExeSolution::BFS(int source, int sink, vector<int>& parent)
{
	const int vertixAmount = this->graph->vertixAmount;
	bool* visited = new bool[vertixAmount];
	for (int i = 0; i < vertixAmount; ++i)
	{
		visited[i] = false;
	}
	std::queue<int> q;
	q.push(source);
	visited[source] = true;
	parent[source] = -1;
	while (!q.empty())
	{
		int curr = q.front();
		q.pop();
		Node* currNode = this->graph->GetAdjList(curr).head;
		while (currNode != nullptr)
		{
			if (!visited[currNode->nodeId] && currNode->capacity > 0)
			{
				q.push(currNode->nodeId);
				visited[currNode->nodeId] = true;
				parent[currNode->nodeId] = curr;
			}
			currNode = currNode->next;
		}
	}
	return visited[sink];
}


bool ExeSolution::Djikstra(Graph& graph, int source, int sink, vector<int>& parent)
{
	Heap Q(graph.vertixAmount);
	vector<int> capacitys(graph.vertixAmount); //Weight array

	for (int i = 0; i < graph.vertixAmount; i++)
	{
		capacitys[i] = INT_MAX;
	}
	capacitys[source] = 0;
	Q.Build(capacitys);

	while (!Q.IsEmpty())
	{
		int u = Q.DeleteMin();
		Node* currNode = this->graph->GetAdjList(u).head;
		while (currNode != nullptr)
		{
			if ((capacitys[currNode->nodeId] > capacitys[u] + currNode->capacity) && currNode->capacity > 0)//TODO > INSTEAD <
			{
				capacitys[currNode->nodeId] = capacitys[u] + currNode->capacity;
				parent[currNode->nodeId] = u;
				Q.DecreaseKey(currNode->nodeId, capacitys[currNode->nodeId]);
			}
			currNode = currNode->next;
		}
	}
	return capacitys[sink] != INT_MAX;
}

